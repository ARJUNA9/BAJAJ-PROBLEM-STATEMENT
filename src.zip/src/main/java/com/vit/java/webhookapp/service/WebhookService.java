package com.vit.java.webhookapp.service;

import com.vit.java.webhookapp.model.WebhookResponse;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import java.util.HashMap;
import java.util.Map;

@Service
public class WebhookService {

    private final RestTemplate restTemplate = new RestTemplate();

    public void processWebhook() {
        String url = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

        // Step 1: Send POST request to generate webhook
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("name", "John Doe");
        requestBody.put("regNo", "REG12347"); // Change to your actual regNo
        requestBody.put("email", "john@example.com"); // Change to your actual email

        ResponseEntity<WebhookResponse> response =
                restTemplate.postForEntity(url, requestBody, WebhookResponse.class);

        WebhookResponse webhookResponse = response.getBody();

        if (webhookResponse == null) {
            System.out.println("Failed to get webhook response");
            return;
        }

        // Debug information
        System.out.println("Webhook URL: " + webhookResponse.getWebhook());
        System.out.println("Access Token: " + webhookResponse.getAccessToken());

        String webhookUrl = webhookResponse.getWebhook();
        String accessToken = webhookResponse.getAccessToken();

        // Extract last two digits of regNo
        String regNo = requestBody.get("regNo");
        int lastTwoDigits = Integer.parseInt(regNo.substring(regNo.length() - 2));

        // Choose SQL Query based on even/odd
        String finalQuery;
        if (lastTwoDigits % 2 == 1) {
            finalQuery = "SELECT P.AMOUNT AS SALARY, " +
                    "CONCAT(E.FIRST_NAME, ' ', E.LAST_NAME) AS NAME, " +
                    "FLOOR(DATEDIFF(CURDATE(), E.DOB) / 365) AS AGE, " +
                    "D.DEPARTMENT_NAME " +
                    "FROM PAYMENTS P " +
                    "JOIN EMPLOYEE E ON P.EMP_ID = E.EMP_ID " +
                    "JOIN DEPARTMENT D ON E.DEPARTMENT = D.DEPARTMENT_ID " +
                    "WHERE DAY(P.PAYMENT_TIME) <> 1 " +
                    "ORDER BY P.AMOUNT DESC " +
                    "LIMIT 1;";
        } else {
            finalQuery = "SELECT E1.EMP_ID, E1.FIRST_NAME, E1.LAST_NAME, D.DEPARTMENT_NAME, " +
                    "(SELECT COUNT(*) FROM EMPLOYEE E2 WHERE E2.DEPARTMENT = E1.DEPARTMENT " +
                    "AND E2.DOB > E1.DOB) AS YOUNGER_EMPLOYEES_COUNT " +
                    "FROM EMPLOYEE E1 " +
                    "JOIN DEPARTMENT D ON E1.DEPARTMENT = D.DEPARTMENT_ID " +
                    "ORDER BY E1.EMP_ID DESC;";
        }

        // Step 3: Submit final SQL query to webhook
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, String> finalBody = new HashMap<>();
        finalBody.put("finalQuery", finalQuery);

        // Debugging output
        System.out.println("DEBUG >>> Webhook URL: " + webhookUrl);
        System.out.println("DEBUG >>> Final Query: " + finalQuery);

        HttpEntity<Map<String, String>> entity = new HttpEntity<>(finalBody, headers);

        // Attempt with Bearer token first
        try {
            headers.set("Authorization", "Bearer " + accessToken);
            restTemplate.postForEntity(webhookUrl, entity, String.class);
            System.out.println("SQL Query submitted successfully with Bearer token!");
        } catch (HttpClientErrorException e) {
            System.out.println("Bearer token failed. Retrying with raw token...");
            try {
                headers.set("Authorization", accessToken); // No Bearer prefix
                restTemplate.postForEntity(webhookUrl, entity, String.class);
                System.out.println("SQL Query submitted successfully with raw token!");
            } catch (HttpClientErrorException ex) {
                System.out.println("Request failed even with raw token: " + ex.getStatusCode());
                System.out.println("Response Body: " + ex.getResponseBodyAsString());
            }
        }
    }
}
